const app=require("./app");
const mongoose=require("mongoose");

app.listen(3000,()=>
{
    console.log("Server is now working");

})