const express=require("express");
const mongoose=require("mongoose");
const app =new express();
const loginRouter=require("./loginRouter.js");