import React, { Component } from 'react'

export default class ExistingComplaints extends Component {
    render() {
        return (
            <div>
                <h4>
                Existing Complaints
                </h4>
            </div>
        )
    }
}
