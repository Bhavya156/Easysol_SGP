import React, { Component } from 'react'

export default class NewComplaints extends Component {
    render() {
        return (
            <div>
                <h4> New Complaints</h4>
            </div>
        )
    }
}
