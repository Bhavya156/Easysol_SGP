
import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import NavbarComp from './components/NavbarComp';


function App() {
  return (
    <div>
      <NavbarComp/>
    </div>
  );
}

export default App;
